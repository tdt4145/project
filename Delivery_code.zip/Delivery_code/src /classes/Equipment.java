package classes;

public class Equipment {
  int EquipmentID;
  String name;
  String description;

  public Equipment(String name, String description){
    this.name = name;
    this.description = description;
  }
}
