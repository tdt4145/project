package classes;

public class ExerciseInfo{
  String exerciseFeat;
  String weight;
  String numberOfSets;

  public ExerciseInfo(String exerciseFeat, String weight, String numberOfSets){
    this.exerciseFeat = exerciseFeat;
    this.weight = weight;
    this.numberOfSets = numberOfSets;
  }
}
