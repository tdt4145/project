package classes;

public class Exercise {
  int exerciseID;
  String name;
  String description;

  public Exercise(String name, String description){
    this.name = name;
    this.description = description;
  }
}
